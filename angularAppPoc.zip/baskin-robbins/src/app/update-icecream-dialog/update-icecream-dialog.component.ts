import { Component, OnInit, Input, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Icecreams } from '../model/icecream.model';

@Component({
  selector: 'app-update-icecream-dialog',
  templateUrl: './update-icecream-dialog.component.html',
  styleUrls: ['./update-icecream-dialog.component.scss']
})
export class UpdateIcecreamDialogComponent  {


  flavour_id: number;
  flavour_name: string;
  price: number;
  updateForm: FormGroup;

  constructor(private formBuilder: FormBuilder ,
              private dialogRef: MatDialogRef<UpdateIcecreamDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Icecreams) { }

  // ngOnInit() {
  //   this.loadForm();
  // }

  // loadForm() {
  //   this.updateForm = new FormGroup({
  //     flavour_id : new FormControl(this.data.element.flavour_id, [
  //       Validators.required
  //     ]),
  //     flavour_name : new FormControl(this.data.element.flavour_name, [
  //       Validators.required
  //     ]),
  //     price : new FormControl(this.data.element.price, [
  //       Validators.required
  //     ])
  // });
  // }

  // onNoClick(): void {
  //   this.dialogRef.close();
  // }

  onUpdateSelect() {
    this.dialogRef.close(this.updateForm.value);
  }

  cancelSelect() {
    this.dialogRef.close();
  }
}
