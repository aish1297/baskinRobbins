import { AddUserPayment } from './dashboard/add-payment-form/add-payment.model';

export interface AppState {
    readonly paymentdetails : AddUserPayment[];
}