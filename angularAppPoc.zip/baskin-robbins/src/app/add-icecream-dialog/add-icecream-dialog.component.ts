import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Icecreams } from '../model/icecream.model';

@Component({
  selector: 'app-add-icecream-dialog',
  templateUrl: './add-icecream-dialog.component.html',
  styleUrls: ['./add-icecream-dialog.component.scss']
})
export class AddIcecreamDialogComponent implements OnInit {

  flavour_id: number;
  flavour_name: string;
  price: number;
  addForm: FormGroup;
  icecreams: any;

  constructor(private formBuilder: FormBuilder ,
              public dialogRef: MatDialogRef<AddIcecreamDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: Icecreams) { }

    // onNoClick(): void {
    //   this.dialogRef.close();
    // }

  ngOnInit() {
    this.addForm = new FormGroup({
      flavour_id: new FormControl(''),
      flavour_name: new FormControl(''),
      price: new FormControl('')
   });
  }

  onAddSelect() {
    this.dialogRef.close(this.addForm.value);
    }

  cancelSelect() {
    this.dialogRef.close();
  }
}
