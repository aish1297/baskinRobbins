import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { GetUsers } from './actions/user.actions';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  
  constructor(private router: Router, public store: Store<any>) { }

  ngOnInit() {
    this.store.dispatch(new GetUsers({}));
  }
  
  onAddPayment() {
    this.router.navigate(['dashboard/addPaymentDetails']);
  }

  onViewUsers() {
    this.router.navigate(['dashboard/userPaymentDetails']);
  }

}
