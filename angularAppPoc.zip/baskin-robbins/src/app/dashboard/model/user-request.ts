export class AddPaymentForUser {
    constructor(
        public name: string,
        public email: string,
        public phone: number 
    ) { }
}