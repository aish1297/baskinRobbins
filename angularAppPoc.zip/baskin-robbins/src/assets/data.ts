// export var single = [
//   {
//     "name": "Germany",
//     "value": 8940000 ,
//   },
//   {
//     "name": "USA",
//     "value": 5000000,
//   },
//   {
//     "name": "France",
//     "value": 7200000
//   },
//   {
//     "name": "India",
//     "value": 8200000
//   }
// ];

export var data = [

  {
    "name": "Germany",
    "value": 7300000,
  },
  {
    "name": "USA",
    "value": 8940000,
  },
  {
    "name": "France",
    "value": 8940000,
  },
  {
    "name": "India",
    "value": 8940000,
  },
];

// export var data = [
//   {
//     "location": [
//       {
//         "place":"GermanyGermanyGermany"
//       },
//       {
//         "place":"GermanyGermany"
//       }
//     ]
//     "series": [
//       {
//         "name": "2010",
//         "value": 7300000
//       },
//       {
//         "name": "2011",
//         "value": 8940000
//       }
//     ]
//   }
// ];
