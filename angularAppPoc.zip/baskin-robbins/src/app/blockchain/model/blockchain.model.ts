export interface Blockchain {
    name: string;
    price: number;
  }