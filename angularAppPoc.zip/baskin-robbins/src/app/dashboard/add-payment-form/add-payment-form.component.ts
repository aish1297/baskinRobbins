import { Component, OnInit,  Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AddPaymentForUser } from '../model/user-request';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { AddPayment } from '../actions/user.actions';
import { AddUserPayment } from './add-payment.model';

@Component({
  selector: 'app-add-payment-form',
  templateUrl: './add-payment-form.component.html',
  styleUrls: ['./add-payment-form.component.scss']
})
export class AddPaymentFormComponent implements OnInit {  
  
  form: FormGroup;
  
  constructor(public store: Store<any>, private fb: FormBuilder, private router : Router) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form =  this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
    });
  }

  onSubmit(name, email, phone) {
    // if(this.form!= null) {
    //   const payload = {
    //     name: this.form.controls.name.value,
    //     email: this.form.controls.email.value,
    //     phone: this.form.controls.phone.value,
    //   };
    // this.store.dispatch(new AddPayment(payload));
    // }
    // this.show = false;
    this.store.dispatch({
      type: 'ADD_PAYMENT',
      payload: <AddUserPayment> {
        name: name,
        email: email,
        phone: phone
      }
    });
  }

  onCancel() {
    this.router.navigate(['dashboard']);
  }

}
