import { AddUserPayment } from '../add-payment-form/add-payment.model';

export const ADD_PAYMENT = "ADD_PAYMENT";

export function addPaymentReducer(state: AddUserPayment[] = [], action) {
    switch (action.type) {
        case ADD_PAYMENT:
            return [...state, action.payload];
        default:
            return state;
    }
}
    


// import { UserDetails } from '../model/user-details';
// import { IAction } from 'src/app/core/core.interface';
// import { UserActionTypes } from '../actions/user.actions';

 
//  export class State {
//      users: UserDetails[];
//      error: null
//  };

//  export const initialState = {
//      users: [],
//      error: null
//  };

//  export function usersReducers(state = initialState, action: IAction) {

//     switch (action.type) {
//         case UserActionTypes.GET_USER:
//             return {
//                 ...state,
//                 users: initialState.users,
//                 error: null
//             };
//         case UserActionTypes.GET_USER_SUCCESS:
//             return {
//                 ...state,
//                 users: action.payload.users,
//                 error: null
//             };
//         case UserActionTypes.GET_USER_FAILED:
//             return {
//                 ...state,
//                 error: action.payload
//             };
        
//         default:
//             return state;
//     }
//  }
