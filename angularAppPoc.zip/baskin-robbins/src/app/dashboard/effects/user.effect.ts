// import { Injectable } from '@angular/core';
// import { Effect, ofType } from '@ngrx/effects';
// import { GetUsers } from '../actions/user.actions';
// import { Observable } from 'rxjs'


// import * as actions from '../actions/user.actions';






// @Injectable() 
// export class UserEffect {

// }