import { Component, OnInit, Inject, Output, EventEmitter, Input, ɵConsole } from '@angular/core';
import { Icecreams } from '../model/icecream.model';
import { IcecreamService } from '../service/icecream.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource} from '@angular/material';
import { AddIcecreamDialogComponent } from '../add-icecream-dialog/add-icecream-dialog.component';
import { UpdateIcecreamDialogComponent } from '../update-icecream-dialog/update-icecream-dialog.component';
import { DeleteIcecreamDialogComponent } from '../delete-icecream-dialog/delete-icecream-dialog.component';


@Component({
  selector: 'app-icecreams',
  templateUrl: './icecreams.component.html',
  styleUrls: ['./icecreams.component.scss']
})
export class IcecreamsComponent implements OnInit {

  displayedColumns: string[] = ['select', 'flavour_id', 'flavour_name', 'price', 'update', 'delete'];

  flavour_id: number;
  flavour_name: string;
  price: number;

  icecreams: Icecreams[];
  selectedData: Icecreams;
  data: Icecreams;

  constructor(private icecreamService: IcecreamService,
              private dialog: MatDialog) {
    console.log('icecreams constructor');
  }

  ngOnInit() {
    console.log('icecreams component loaded');
    this.getIcecreams();
  }

  dialogRefAdd: MatDialogRef<AddIcecreamDialogComponent>;
  dialogRefUpdate: MatDialogRef<UpdateIcecreamDialogComponent>;
  dialogRefDelete: MatDialogRef<DeleteIcecreamDialogComponent>;

  getIcecreams() {
    this.icecreamService.getIcecreams()
                        .subscribe((data: Icecreams[])=> {
                          this.icecreams = data;
                          console.log(this.icecreams);
    })
  }

  openAddDialog(element, i) {
    this.dialogRefAdd = this.dialog.open(AddIcecreamDialogComponent, {
    data : {element}
    });
    this.dialogRefAdd.afterClosed()
                     .subscribe(newData => {
                        this.icecreams.push(this.data);
                        this.icecreams = [...this.icecreams];
    });
  }

  openEditDialog(element, i) {
    this.dialogRefUpdate = this.dialog.open(UpdateIcecreamDialogComponent, {
      data: {element}
    });
    this.dialogRefUpdate.afterClosed()
                        .subscribe(data => {
                          this.selectedData = this.icecreams[i];
                          this.selectedData = data;
                          this.icecreams[i] = this.selectedData;
                          this.icecreams = [...this.icecreams];
    });
  }

  openDeleteDialog(index) {
    this.dialogRefDelete = this.dialog.open(DeleteIcecreamDialogComponent);
    this.dialogRefDelete.afterClosed()
                        .subscribe(data => {
                          if (data) {
                              this.icecreams.splice(index, 1);
                              this.icecreams = [...this.icecreams];
                          }
    })
  }
}
