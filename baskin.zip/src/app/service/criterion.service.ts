import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CriterionService {

  constructor(private http: HttpClient) { }

  baseUrl = 'http://192.168.2.156:3000/onsiteSurveyDetails';

  getCriterionData() {
    return this.http.get(this.baseUrl);
  }

}
