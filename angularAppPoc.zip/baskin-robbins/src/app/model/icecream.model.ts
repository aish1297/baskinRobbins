export class Icecreams {

  flavour_id: number;
  flavour_name: string;
  price: number;

}
