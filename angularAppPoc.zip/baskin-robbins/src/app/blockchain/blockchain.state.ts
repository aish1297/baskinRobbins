import { Blockchain } from './model/blockchain.model';

export interface AppState {
  readonly blockchain: Blockchain[];
}