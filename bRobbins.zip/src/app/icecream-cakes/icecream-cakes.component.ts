import { Component, OnInit } from '@angular/core';
import { single, multi } from 'src/assets/data';


@Component({
  selector: 'app-icecream-cakes',
  templateUrl: './icecream-cakes.component.html',
  styleUrls: ['./icecream-cakes.component.scss']
})
export class IcecreamCakesComponent implements OnInit {

  single: any[];
  multi: any[];

  view: any[] = [800, 200];
  constructor() {
    Object.assign(this, {single, multi})
   }

  ngOnInit() { }

    trimXAxisTicks = true;
    trimYAxisTicks = false;
    showXAxis = true;
    showYAxis = false;
    gradient = false;
    showLegend = true;
    showXAxisLabel = false;
    showYAxisLabel = false;
    maxXAxisTickLength = 3;

  colorScheme = {
    domain: ['#5AA454',
             '#A10A28',
             '#C7B42C',
             '#AAAAAA']
  };
}
