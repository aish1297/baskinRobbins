import { Component, OnInit } from '@angular/core';
import { CriterionService } from '../service/criterion.service';

@Component({
  selector: 'app-signature-cones',
  templateUrl: './signature-cones.component.html',
  styleUrls: ['./signature-cones.component.scss']
})
export class SignatureConesComponent implements OnInit {
  criterion: any = [];

  // data: Criterion;
  // criterion: onsiteSurveyDetails[];

  constructor(private criterionService: CriterionService) { }

  ngOnInit() { this.getCriterion(); }

  getCriterion() {
    this.criterionService.getCriterionData().subscribe(data => {
      this.criterion = data;  
      // console.log(data[0].standards.length);
      // console.log(this.criterion[0].standards.length);
      // console.log(this.criterion[0].standards.length);
      console.log(data[0].standards[0].criteria.length);
      console.log(data[1].standards[0].criteria.length);
      console.log(data[2].standards[0].criteria.length);
    });
  }
}
