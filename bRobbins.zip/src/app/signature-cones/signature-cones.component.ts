import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signature-cones',
  templateUrl: './signature-cones.component.html',
  styleUrls: ['./signature-cones.component.scss']
})
export class SignatureConesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
