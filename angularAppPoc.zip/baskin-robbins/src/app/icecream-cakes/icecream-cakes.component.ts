import { Component, OnInit } from '@angular/core';
import { data } from 'src/assets/data';


@Component({
  selector: 'app-icecream-cakes',
  templateUrl: './icecream-cakes.component.html',
  styleUrls: ['./icecream-cakes.component.scss']
})
export class IcecreamCakesComponent implements OnInit {

  // single: any[];
  data: any[];

  view: any[] = [800, 130];
  constructor() {
    Object.assign(this, {data})
   }

  ngOnInit() {
    console.log(data);

  }

    trimXAxisTicks = false;
    trimYAxisTicks = false;
    showXAxis = true;
    showYAxis = true;
    gradient = false;
    showLegend = true;
    showXAxisLabel = true;
    showYAxisLabel = true;
    // maxXAxisTickLength = 3;

  colorScheme = {
    domain: ['#5AA454',
             '#A10A28',
             '#C7B42C',
             '#AAAAAA']
  };


}
