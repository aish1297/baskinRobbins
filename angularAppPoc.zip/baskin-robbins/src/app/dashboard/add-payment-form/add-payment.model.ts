export interface AddUserPayment {
    name: string,
    email: string,
    phone: number
}