import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icecream-cakes',
  templateUrl: './icecream-cakes.component.html',
  styleUrls: ['./icecream-cakes.component.scss']
})
export class IcecreamCakesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
