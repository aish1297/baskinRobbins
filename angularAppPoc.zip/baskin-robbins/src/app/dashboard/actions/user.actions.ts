import { Action } from '@ngrx/store';
// import { UserDetails } from '../model/user-details';
import { AddPaymentForUser } from '../model/user-request';

export enum UserActionTypes {
    GET_USER = "GET_USERS",
    GET_USER_SUCCESS = "GET_USER_SUCCESS",
    GET_USER_FAILED = "GET_USER_FAILED",
    ADD_PAYMENT_FOR_USER = "ADD_PAYMENT_FOR_USER",
    ADD_PAYMENT_SUCCESS = "ADD_PAYMENT_SUCCESS",
    ADD_PAYMENT_FAILED = "ADD_PAYMENT_FAILED",
}

export class GetUsers implements Action {
    readonly type = UserActionTypes.GET_USER;
    constructor(public payload: any) { }
}

export class GetUserSuccess implements Action {
    readonly type = UserActionTypes.GET_USER_SUCCESS;
    constructor(public payload: any) { }
}

export class GetUserFailed implements Action {
    readonly type = UserActionTypes.GET_USER_FAILED;
    constructor(public payload: any) { }
}

export class AddPayment implements Action {
    readonly type = UserActionTypes.ADD_PAYMENT_FOR_USER;
    constructor(public payload: AddPaymentForUser) { }
}

export class AddPaymentSuccess implements Action {
    readonly type = UserActionTypes.ADD_PAYMENT_SUCCESS;
    constructor(public payload: any) { }
}

export class AddPaymentFailed implements Action {
    readonly type = UserActionTypes.ADD_PAYMENT_FAILED;
    constructor(public payload: any) { }
}

export type UserActions = 
    GetUsers
    | GetUserSuccess
    | GetUserFailed
    | AddPayment
    | AddPaymentSuccess
    | AddPaymentFailed;