import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AddUserPayment } from '../add-payment-form/add-payment.model';
import { AppState } from 'src/app/app.state';

@Component({
  selector: 'app-user-payment-details',
  templateUrl: './user-payment-details.component.html',
  styleUrls: ['./user-payment-details.component.scss']
})
export class UserPaymentDetailsComponent implements OnInit {

  userDetails: Observable<AddUserPayment[]>;
  
  constructor(private store: Store<AppState>) {
    this.userDetails = this.store.select(state => state.paymentdetails);
   }

  ngOnInit() {
  }

  // displayedColumns : ['name', 'email', 'phone'];

}
